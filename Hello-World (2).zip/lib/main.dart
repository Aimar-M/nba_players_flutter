import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NBA Players App',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        accentColor: Colors.deepOrangeAccent,
        fontFamily: 'Roboto',
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final List<Player> players = [
    Player(name: 'LeBron James', image: 'assets/images/lebron.jpg'),
    Player(name: 'Stephen Curry', image: 'assets/images/curry.jpg'),
    Player(name: 'Kevin Durant', image: 'assets/images/kd.jpg'),
    Player(name: 'Kawhi Leonard', image: 'assets/images/leonard.jpg'),
    Player(name: 'James Harden', image: 'assets/images/harden.jpg'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NBA Players'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(players.length, (index) {
          return Center(
            child: Column(
              children: <Widget>[
                Image.asset(
                  players[index].image,
                  height: 150,
                  width: 150,
                ),
                Text(
                  players[index].name,
                  style: Theme.of(context).textTheme.headline6,
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class Player {
  final String name;
  final String image;

  Player({required this.name, required this.image});
}
